@echo off
setlocal
py -3 "%~dp0apply_dlc_xdelta.py" %*
set "PATCH_EXIT=%ERRORLEVEL%"
if "%~1"=="" pause
exit /b %PATCH_EXIT%
