#!/usr/bin/env python3
"""Safely apply one Prinny PSP DLC xdelta pack into a new PSP/GAME tree."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_path(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_manifest(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    required = {"pack_id", "game_id", "files"}
    if not required.issubset(value) or not isinstance(value["files"], list):
        raise ValueError("지원하지 않는 manifest 형식입니다.")
    return value


def xdelta_executable(script_dir: Path) -> str:
    local_names = ("xdelta3.exe", "xdelta3") if os.name == "nt" else ("xdelta3", "xdelta3.exe")
    for name in local_names:
        candidate = script_dir / name
        if candidate.is_file():
            return str(candidate)
    found = shutil.which("xdelta3")
    if found:
        return found
    raise FileNotFoundError(
        "xdelta3를 찾을 수 없습니다. xdelta3 또는 xdelta3.exe를 설치하거나 "
        "이 패치 폴더에 넣어 주십시오."
    )


def entry_source_variants(entry: dict[str, Any]) -> list[dict[str, str]]:
    variants = entry.get("source_variants")
    if variants is None:
        variant = {"source_sha256": entry["source_sha256"]}
        if entry["mode"] == "patch":
            variant["patch"] = entry["patch"]
            variant["patch_sha256"] = entry["patch_sha256"]
        return [variant]
    if not isinstance(variants, list) or not variants:
        raise ValueError(f"{entry.get('name', 'unknown')}: source_variants가 비어 있습니다.")
    required = {"source_sha256"}
    if entry["mode"] == "patch":
        required |= {"patch", "patch_sha256"}
    for variant in variants:
        if not isinstance(variant, dict) or not required.issubset(variant):
            raise ValueError(f"{entry.get('name', 'unknown')}: 잘못된 source_variants 형식입니다.")
    return variants


def matched_source_data(
    candidates: list[tuple[str, bytes]], accepted_sha256: set[str], source: Path, name: str,
) -> tuple[bytes, str]:
    matches: list[tuple[bytes, str]] = []
    mismatches: list[str] = []
    for label, data in candidates:
        digest = sha256_bytes(data)
        if digest in accepted_sha256:
            matches.append((data, digest))
        else:
            mismatches.append(label)
    if not matches:
        raise ValueError(f"{source}: SHA-256이 맞는 원본 {name}을 찾지 못했습니다.")
    if mismatches:
        raise ValueError(f"{source}: 내용이 서로 다른 {name} 후보가 함께 있어 중단합니다.")
    matched_hashes = {digest for _, digest in matches}
    if len(matched_hashes) != 1:
        raise ValueError(f"{source}: 서로 다른 지원 지역의 {name} 후보가 함께 있어 중단합니다.")
    return matches[0]


def zip_member_data(
    source: Path, game_ids: set[str], name: str, accepted_sha256: set[str],
) -> tuple[bytes, str]:
    with zipfile.ZipFile(source) as archive:
        candidates: list[str] = []
        for member in archive.namelist():
            parts = PurePosixPath(member).parts
            folded_parts = {part.casefold() for part in parts}
            if (
                parts
                and parts[-1].casefold() == name.casefold()
                and {game_id.casefold() for game_id in game_ids} & folded_parts
            ):
                candidates.append(member)
        if not candidates:
            basename_matches = [m for m in archive.namelist() if PurePosixPath(m).name.casefold() == name.casefold()]
            candidates = basename_matches
        return matched_source_data(
            [(member, archive.read(member)) for member in candidates], accepted_sha256, source, name,
        )


def folder_file_data(
    source: Path, game_ids: set[str], name: str, accepted_sha256: set[str],
) -> tuple[bytes, str]:
    candidates = [source / name]
    for game_id in sorted(game_ids):
        candidates.extend((source / game_id / name, source / "PSP" / "GAME" / game_id / name))
    candidates.extend(path for path in source.rglob(name) if path not in candidates)
    seen: set[Path] = set()
    found: list[tuple[str, bytes]] = []
    for candidate in candidates:
        if candidate in seen or not candidate.is_file():
            continue
        seen.add(candidate)
        found.append((str(candidate), candidate.read_bytes()))
    return matched_source_data(found, accepted_sha256, source, name)


def source_data(
    source: Path, game_ids: set[str], name: str, accepted_sha256: set[str],
) -> tuple[bytes, str]:
    if source.is_file() and zipfile.is_zipfile(source):
        data, actual = zip_member_data(source, game_ids, name, accepted_sha256)
    elif source.is_dir():
        data, actual = folder_file_data(source, game_ids, name, accepted_sha256)
    else:
        raise ValueError("원본 경로는 DLC ZIP 또는 압축을 푼 폴더여야 합니다.")
    if actual not in accepted_sha256:
        raise ValueError(f"{name}: 원본 SHA-256 불일치: {actual}")
    return data, actual


def is_within(child: Path, parent: Path) -> bool:
    try:
        child.relative_to(parent)
        return True
    except ValueError:
        return False


def apply_pack(manifest_path: Path, source: Path, output_root: Path) -> dict[str, Any]:
    manifest_path = manifest_path.resolve()
    script_dir = manifest_path.parent
    manifest = load_manifest(manifest_path)
    source = source.expanduser().resolve()
    output_root = output_root.expanduser().resolve()
    if source.is_dir() and is_within(output_root, source):
        raise ValueError("원본 폴더 자체 또는 그 하위에는 출력할 수 없습니다. 별도 출력 폴더를 지정하십시오.")

    game_id = manifest["game_id"]
    source_game_ids = set(manifest.get("source_game_ids", []))
    source_game_ids.add(manifest.get("source_game_id", game_id))
    source_game_ids.add(game_id)
    install_dir = output_root / "PSP" / "GAME" / game_id
    xdelta = xdelta_executable(script_dir)

    originals: dict[str, bytes] = {}
    selected_variants: dict[str, dict[str, str]] = {}
    existing_actions: dict[str, str] = {}
    for entry in manifest["files"]:
        name = entry["name"]
        variants = entry_source_variants(entry)
        variants_by_hash = {variant["source_sha256"]: variant for variant in variants}
        originals[name], original_hash = source_data(source, source_game_ids, name, set(variants_by_hash))
        selected_variants[name] = variants_by_hash[original_hash]
        destination = install_dir / name
        if destination.exists():
            existing_hash = sha256_path(destination)
            accepted = set(entry.get("accepted_existing_sha256", []))
            if existing_hash not in accepted:
                raise ValueError(
                    f"기존 출력 파일 {destination}의 SHA-256이 알려진 원본/한글판과 다릅니다: {existing_hash}"
                )
            if entry["mode"] == "patch" and existing_hash == entry["target_sha256"]:
                existing_actions[name] = "already_patched"
            elif entry["mode"] == "copy_if_missing":
                existing_actions[name] = "preserve_existing"
            else:
                existing_actions[name] = "replace_known_original"
        else:
            existing_actions[name] = "create"

    output_root.mkdir(parents=True, exist_ok=True)
    stage = Path(tempfile.mkdtemp(prefix=f".{manifest['pack_id']}_", dir=output_root))
    staged_outputs: dict[str, Path] = {}
    results: list[dict[str, Any]] = []
    try:
        for entry in manifest["files"]:
            name = entry["name"]
            action = existing_actions[name]
            if action in {"already_patched", "preserve_existing"}:
                results.append({"name": name, "action": action, "sha256": sha256_path(install_dir / name)})
                continue

            source_path = stage / "source" / name
            candidate = stage / "result" / name
            source_path.parent.mkdir(parents=True, exist_ok=True)
            candidate.parent.mkdir(parents=True, exist_ok=True)
            source_path.write_bytes(originals[name])
            if entry["mode"] == "patch":
                variant = selected_variants[name]
                patch_path = script_dir / variant["patch"]
                if not patch_path.is_file():
                    raise FileNotFoundError(f"xdelta 파일이 없습니다: {patch_path}")
                patch_sha = sha256_path(patch_path)
                if patch_sha != variant["patch_sha256"]:
                    raise ValueError(f"xdelta 자체 SHA-256 불일치: {patch_path.name}")
                process = subprocess.run(
                    [xdelta, "-d", "-f", "-s", str(source_path), str(patch_path), str(candidate)],
                    capture_output=True,
                    text=True,
                )
                if process.returncode != 0:
                    message = process.stderr.strip() or process.stdout.strip()
                    raise RuntimeError(f"{name} xdelta 적용 실패: {message}")
                expected_result = entry["target_sha256"]
            elif entry["mode"] == "copy_if_missing":
                candidate.write_bytes(originals[name])
                expected_result = entry["target_sha256"]
            else:
                raise ValueError(f"지원하지 않는 작업 모드: {entry['mode']}")

            actual_result = sha256_path(candidate)
            if actual_result != expected_result:
                raise ValueError(f"{name}: 결과 SHA-256 불일치: {actual_result} != {expected_result}")
            staged_outputs[name] = candidate
            results.append({"name": name, "action": action, "sha256": actual_result})

        install_dir.mkdir(parents=True, exist_ok=True)
        for name, candidate in staged_outputs.items():
            os.replace(candidate, install_dir / name)

        # Verify the actual shippable files after commit, including files kept
        # from an earlier individual patch application.
        final_files: dict[str, str] = {}
        for entry in manifest["files"]:
            destination = install_dir / entry["name"]
            actual = sha256_path(destination)
            accepted = set(entry.get("accepted_final_sha256", [entry["target_sha256"]]))
            if actual not in accepted:
                raise ValueError(f"최종 파일 검증 실패: {destination}: {actual}")
            final_files[entry["name"]] = actual

        report = {
            "format": "prinny_dlc_xdelta_apply_report_v1",
            "status": "PASS",
            "pack_id": manifest["pack_id"],
            "scope": manifest.get("scope", "individual_dlc"),
            "selected_dlc": manifest.get("selected_dlc"),
            "source": str(source),
            "source_files": {
                name: selected_variants[name]["source_sha256"] for name in sorted(selected_variants)
            },
            "install_directory": str(install_dir),
            "operations": results,
            "final_files": final_files,
        }
        report_path = output_root / f"apply_report_{manifest['pack_id']}.json"
        report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        return report
    finally:
        shutil.rmtree(stage, ignore_errors=True)


def main() -> None:
    parser = argparse.ArgumentParser(description="프리니 PSP DLC 통합 xdelta 안전 적용기")
    parser.add_argument("source", nargs="?", type=Path, help="원본 DLC ZIP 또는 압축을 푼 폴더")
    parser.add_argument("output", nargs="?", type=Path, help="새 PSP/GAME 구조를 만들 출력 폴더")
    parser.add_argument("--manifest", type=Path, default=Path(__file__).with_name("manifest.json"))
    args = parser.parse_args()

    source = args.source
    if source is None:
        source = Path(input("원본 DLC ZIP 또는 폴더 경로: ").strip().strip('"'))
    output = args.output or (Path(__file__).resolve().parent / "patched_output")
    try:
        report = apply_pack(args.manifest, source, output)
    except Exception as exc:
        print(f"오류: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
    print(f"적용 완료: {report['install_directory']}")
    print("이 출력 폴더의 PSP 디렉터리를 메모리스틱 루트에 복사하십시오.")


if __name__ == "__main__":
    main()
