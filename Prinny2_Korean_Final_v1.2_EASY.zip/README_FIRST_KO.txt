프리니 2 비공식 한국어 패치 v1.2 - 간편 적용판
=================================================

이 패치에는 게임 ISO와 원본 DLC가 들어 있지 않습니다.
본인이 정품에서 추출한 무수정 일본판 ISO와 원본 DLC를 준비하십시오.

[가장 간단한 실행]

Windows: START_PATCH.bat를 더블 클릭합니다.
Linux:   ./START_PATCH.sh 를 실행합니다.

메뉴에서 다음 중 하나를 선택할 수 있습니다.

1. 본편 + DLC 모두 패치
2. 본편만 패치
3. DLC만 패치

[필요 도구]

- Python 3
- xdelta3

Windows에서는 xdelta3.exe를 이 README와 같은 폴더에 넣으면 됩니다.
Linux에서는 패키지 관리자로 xdelta3를 설치할 수 있습니다.

[본편 원본 조건]

게임 ID: NPJH50211
크기: 822,214,656 바이트
SHA-256: 4c509ba4d8d2dfcd2635228526fa2955e25ccbb511878861ed31ecfcf2829087

패치 후 최종 ISO SHA-256:
6d1268e2c4b6443fc734fb206a35a0afdc484063ab543bd56916e917600ec868

[DLC]

일본판 NPJH50211 또는 유럽판 NPEH00101 DLC ZIP/폴더를 자동 판별합니다.
두 지역 중 하나만 입력하십시오. 출력 결과는 모두 일본판 한글 본편용
PSP/GAME/NPJH50211 폴더로 만들어집니다.

DLC는 게임 ISO 안에 넣는 데이터가 아닙니다. 패치 결과의 PSP 폴더를
PPSSPP 메모리스틱 폴더 또는 PSP/PS Vita 메모리스틱 루트에 복사하십시오.

PPSSPP 기본 위치 예시:
memstick/PSP/GAME/NPJH50211/

[안전 검사]

적용기는 원본, xdelta, 결과 파일의 SHA-256을 검사합니다.
원본 ISO를 덮어쓰지 않으며, 이미 다른 파일이 있는 출력 경로에는 쓰지 않습니다.

