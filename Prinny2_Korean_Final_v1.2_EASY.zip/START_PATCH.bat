@echo off
setlocal
cd /d "%~dp0"
py -3 START_PATCH.py
set "PATCH_EXIT=%ERRORLEVEL%"
echo.
pause
exit /b %PATCH_EXIT%

