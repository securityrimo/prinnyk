#!/usr/bin/env python3
"""Interactive front end for the final Prinny 2 game and DLC patches."""

from __future__ import annotations

import os
import sys
from pathlib import Path

from apply_game_xdelta import FINAL_NAME, apply_game_patch
from DLC.apply_dlc_xdelta import apply_pack


ROOT = Path(__file__).resolve().parent
DLC_MANIFEST = ROOT / "DLC" / "manifest.json"


def entered_path(prompt: str) -> Path:
    value = input(prompt).strip().strip('"')
    if not value:
        raise ValueError("경로를 입력하지 않았습니다.")
    return Path(value)


def patch_game() -> None:
    source = entered_path("무수정 일본판 원본 ISO 경로: ")
    output_text = input(f"출력 ISO 경로(Enter: 원본 옆 {FINAL_NAME}): ").strip().strip('"')
    output = Path(output_text) if output_text else source.expanduser().resolve().with_name(FINAL_NAME)
    apply_game_patch(source, output, ROOT)


def patch_dlc() -> None:
    source = entered_path("원본 DLC ZIP 또는 폴더 경로(일본판/유럽판): ")
    output_text = input("DLC 출력 폴더(Enter: 패치 폴더의 patched_DLC): ").strip().strip('"')
    output = Path(output_text) if output_text else ROOT / "patched_DLC"
    report = apply_pack(DLC_MANIFEST, source, output)
    print(f"DLC 패치 완료: {report['install_directory']}")
    print("출력된 PSP 폴더를 PPSSPP/PSP 또는 메모리스틱 루트에 복사하십시오.")


def main() -> None:
    # Let the DLC worker find an xdelta3(.exe) placed beside this launcher.
    os.environ["PATH"] = str(ROOT) + os.pathsep + os.environ.get("PATH", "")
    print("프리니 2 한국어 패치 v1.2")
    print("1. 본편 + DLC 모두 패치")
    print("2. 본편만 패치")
    print("3. DLC만 패치")
    choice = input("선택 [1/2/3]: ").strip()
    try:
        if choice == "1":
            patch_game()
            patch_dlc()
        elif choice == "2":
            patch_game()
        elif choice == "3":
            patch_dlc()
        else:
            raise ValueError("1, 2, 3 중 하나를 선택하십시오.")
    except Exception as exc:
        print(f"오류: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc


if __name__ == "__main__":
    main()

