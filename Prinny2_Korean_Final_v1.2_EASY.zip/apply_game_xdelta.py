#!/usr/bin/env python3
"""Safely apply the final Prinny 2 Korean ISO xdelta patch."""

from __future__ import annotations

import argparse
import hashlib
import os
import shutil
import subprocess
import sys
from pathlib import Path


ORIGINAL_SIZE = 822_214_656
ORIGINAL_SHA256 = "4c509ba4d8d2dfcd2635228526fa2955e25ccbb511878861ed31ecfcf2829087"
PATCH_NAME = "Prinny2_NPJH50211_KR_v1.2.xdelta"
PATCH_SHA256 = "387d3ce5a2dfb03660b09c7bdb47a66b0fbe81405a651672ad51d1607568d55a"
FINAL_SIZE = 822_214_656
FINAL_SHA256 = "6d1268e2c4b6443fc734fb206a35a0afdc484063ab543bd56916e917600ec868"
FINAL_NAME = "Prinny2_NPJH50211_KR_v1.2_FINAL.iso"


def sha256_path(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def find_xdelta(script_dir: Path) -> str:
    local_names = ("xdelta3.exe", "xdelta3") if os.name == "nt" else ("xdelta3", "xdelta3.exe")
    for name in local_names:
        candidate = script_dir / name
        if candidate.is_file():
            return str(candidate)
    executable = shutil.which("xdelta3")
    if executable:
        return executable
    raise FileNotFoundError(
        "xdelta3를 찾을 수 없습니다. xdelta3 또는 xdelta3.exe를 설치하거나 "
        "이 패치 폴더에 넣어 주십시오."
    )


def apply_game_patch(source: Path, output: Path, script_dir: Path | None = None) -> Path:
    script_dir = (script_dir or Path(__file__).resolve().parent).resolve()
    source = source.expanduser().resolve()
    output = output.expanduser().resolve()
    patch = script_dir / PATCH_NAME

    if not source.is_file():
        raise FileNotFoundError(f"원본 ISO를 찾을 수 없습니다: {source}")
    if source.stat().st_size != ORIGINAL_SIZE:
        raise ValueError(f"원본 ISO 크기가 다릅니다: {source.stat().st_size} != {ORIGINAL_SIZE}")
    source_hash = sha256_path(source)
    if source_hash != ORIGINAL_SHA256:
        raise ValueError(f"지원하는 일본판 원본 ISO가 아닙니다. SHA-256: {source_hash}")
    if not patch.is_file() or sha256_path(patch) != PATCH_SHA256:
        raise ValueError("본편 xdelta 파일이 없거나 손상됐습니다.")

    if output.exists():
        if output.is_file() and output.stat().st_size == FINAL_SIZE and sha256_path(output) == FINAL_SHA256:
            print(f"이미 완성된 최종 ISO입니다: {output}")
            return output
        raise FileExistsError(f"출력 파일이 이미 존재합니다. 다른 경로를 지정하십시오: {output}")
    if output == source:
        raise ValueError("원본 ISO와 출력 ISO는 같은 경로일 수 없습니다.")

    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_name(output.name + ".tmp")
    if temporary.exists():
        raise FileExistsError(f"임시 출력이 이미 존재합니다: {temporary}")
    try:
        process = subprocess.run(
            [find_xdelta(script_dir), "-d", "-f", "-s", str(source), str(patch), str(temporary)],
            capture_output=True,
            text=True,
        )
        if process.returncode != 0:
            message = process.stderr.strip() or process.stdout.strip()
            raise RuntimeError(f"xdelta 적용 실패: {message}")
        if temporary.stat().st_size != FINAL_SIZE:
            raise ValueError(f"결과 ISO 크기 불일치: {temporary.stat().st_size} != {FINAL_SIZE}")
        final_hash = sha256_path(temporary)
        if final_hash != FINAL_SHA256:
            raise ValueError(f"결과 ISO SHA-256 불일치: {final_hash}")
        os.replace(temporary, output)
    finally:
        if temporary.exists():
            temporary.unlink()

    print(f"본편 패치 완료: {output}")
    print(f"SHA-256: {FINAL_SHA256}")
    return output


def main() -> None:
    parser = argparse.ArgumentParser(description="프리니 2 일본판 ISO → 최종 한국어판 안전 적용기")
    parser.add_argument("source", nargs="?", type=Path, help="무수정 일본판 원본 ISO")
    parser.add_argument("output", nargs="?", type=Path, help="생성할 최종 한국어 ISO")
    args = parser.parse_args()
    source = args.source
    if source is None:
        source = Path(input("무수정 일본판 원본 ISO 경로: ").strip().strip('"'))
    output = args.output or source.expanduser().resolve().with_name(FINAL_NAME)
    try:
        apply_game_patch(source, output)
    except Exception as exc:
        print(f"오류: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc


if __name__ == "__main__":
    main()

